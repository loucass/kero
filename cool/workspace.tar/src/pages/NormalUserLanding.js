import React from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col, Button, Card } from 'react-bootstrap';
import { FaRobot, FaChartLine, FaShieldAlt, FaRocket, FaBrain, FaCloud } from 'react-icons/fa';
import { useLanguage } from '../contexts/LanguageContext';
import '../styles/normal-user-landing.css';

const NormalUserLanding = () => {
  const { t } = useLanguage();

  const features = [
    {
      icon: <FaRobot className="feature-icon" />,
      title: 'AI-Powered Analytics',
      description: 'Advanced artificial intelligence algorithms to analyze your data and provide actionable insights.'
    },
    {
      icon: <FaChartLine className="feature-icon" />,
      title: 'Real-time Processing',
      description: 'Process your data in real-time with our high-performance computing infrastructure.'
    },
    {
      icon: <FaShieldAlt className="feature-icon" />,
      title: 'Enterprise Security',
      description: 'Bank-level security with end-to-end encryption and compliance with international standards.'
    },
    {
      icon: <FaRocket className="feature-icon" />,
      title: 'Lightning Fast',
      description: 'Optimized performance with sub-second response times for all your operations.'
    },
    {
      icon: <FaBrain className="feature-icon" />,
      title: 'Machine Learning',
      description: 'Continuous learning algorithms that improve over time based on your usage patterns.'
    },
    {
      icon: <FaCloud className="feature-icon" />,
      title: 'Cloud Infrastructure',
      description: 'Scalable cloud architecture that grows with your business needs.'
    }
  ];

  return (
    <div className="normal-landing">
      {/* Hero Section */}
      <section className="hero-section">
        <Container>
          <Row className="align-items-center min-vh-100">
            <Col lg={6} className="hero-content">
              <div className="hero-text">
                <h1 className="hero-title float-animation">
                  {t('welcome')}
                </h1>
                <p className="hero-subtitle pulse-animation">
                  {t('subtitle')}
                </p>
                <div className="hero-buttons">
                  <Button as={Link} to="/signup" size="lg" className="hero-btn-primary me-3">
                    {t('getStarted')}
                  </Button>
                  <Button as={Link} to="/login" size="lg" variant="outline-light" className="hero-btn-secondary">
                    {t('login')}
                  </Button>
                </div>
              </div>
            </Col>
            <Col lg={6} className="hero-visual">
              <div className="hero-animation">
                <div className="floating-card glow-animation">
                  <div className="card-content">
                    <div className="ai-brain">
                      <FaBrain className="brain-icon" />
                    </div>
                    <div className="data-points">
                      {[...Array(20)].map((_, i) => (
                        <div key={i} className="data-point" style={{ 
                          left: `${Math.random() * 100}%`,
                          top: `${Math.random() * 100}%`,
                          animationDelay: `${Math.random() * 2}s`
                        }} />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Features Section */}
      <section className="features-section">
        <Container>
          <Row className="text-center mb-5">
            <Col>
              <h2 className="section-title">{t('features')}</h2>
              <p className="section-subtitle">
                Discover the powerful features that make our platform stand out
              </p>
            </Col>
          </Row>
          <Row>
            {features.map((feature, index) => (
              <Col md={6} lg={4} className="mb-4" key={index}>
                <Card className="feature-card h-100">
                  <Card.Body className="text-center">
                    <div className="feature-icon-wrapper">
                      {feature.icon}
                    </div>
                    <Card.Title className="feature-title">{feature.title}</Card.Title>
                    <Card.Text className="feature-description">
                      {feature.description}
                    </Card.Text>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </Container>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <Container>
          <Row className="text-center">
            <Col>
              <div className="cta-content">
                <h2 className="cta-title">Ready to Transform Your Business?</h2>
                <p className="cta-subtitle">
                  Join thousands of satisfied users who have already transformed their operations with our AI platform.
                </p>
                <Button as={Link} to="/signup" size="lg" className="cta-btn">
                  Start Your Free Trial
                </Button>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
    </div>
  );
};

export default NormalUserLanding;