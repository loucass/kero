import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col, Card, Button, Alert, Badge } from 'react-bootstrap';
import { FaWallet, FaCrown, FaChartLine, FaBell, FaCog, FaUser, FaArrowRight } from 'react-icons/fa';
import { useLanguage } from '../../contexts/LanguageContext';
import '../../styles/user-dashboard.css';

const UserDashboard = () => {
  const { t } = useLanguage();
  const [userData, setUserData] = useState({
    balance: 0,
    subscriptions: [],
    loading: true,
    error: ''
  });

  useEffect(() => {
    // Placeholder for backend integration
    const fetchUserData = async () => {
      try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Placeholder data
        setUserData({
          balance: 150.75,
          subscriptions: [
            {
              id: 1,
              name: 'Basic Analytics',
              price: 29.99,
              status: 'active',
              nextBilling: '2024-02-15'
            }
          ],
          loading: false,
          error: ''
        });
      } catch (error) {
        setUserData(prev => ({
          ...prev,
          loading: false,
          error: 'Failed to load user data'
        }));
      }
    };

    fetchUserData();
  }, []);

  const { balance, subscriptions, loading, error } = userData;

  if (loading) {
    return (
      <div className="dashboard-page">
        <Container>
          <Row className="justify-content-center">
            <Col md={12} className="text-center">
              <div className="loading-spinner">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">{t('loading')}</span>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </div>
    );
  }

  return (
    <div className="dashboard-page">
      <Container>
        <Row className="mb-4">
          <Col>
            <h1 className="dashboard-title">{t('dashboard')}</h1>
            <p className="dashboard-subtitle">Welcome back! Here's your account overview.</p>
          </Col>
        </Row>

        {error && (
          <Row className="mb-4">
            <Col>
              <Alert variant="danger">{error}</Alert>
            </Col>
          </Row>
        )}

        {/* Premium Notification */}
        <Row className="mb-4">
          <Col>
            <Alert className="premium-notification">
              <div className="d-flex align-items-center">
                <FaBell className="notification-icon me-3" />
                <div className="flex-grow-1">
                  <strong>Premium Upgrade Available</strong>
                  <p className="mb-0">{t('premiumNotification')}</p>
                </div>
                <Button variant="primary" size="sm" as={Link} to="/services">
                  Upgrade Now <FaArrowRight className="ms-1" />
                </Button>
              </div>
            </Alert>
          </Col>
        </Row>

        {/* Balance Card */}
        <Row className="mb-4">
          <Col md={6} lg={4}>
            <Card className="balance-card">
              <Card.Body>
                <div className="balance-header">
                  <FaWallet className="balance-icon" />
                  <span className="balance-label">{t('balance')}</span>
                </div>
                <div className="balance-amount">
                  ${balance.toFixed(2)}
                </div>
                <div className="balance-actions">
                  <Button variant="outline-primary" size="sm" as={Link} to="/wallet">
                    Add Funds
                  </Button>
                </div>
              </Card.Body>
            </Card>
          </Col>

          {/* Quick Stats */}
          <Col md={6} lg={4}>
            <Card className="stats-card">
              <Card.Body>
                <div className="stats-header">
                  <FaChartLine className="stats-icon" />
                  <span className="stats-label">Active Services</span>
                </div>
                <div className="stats-value">
                  {subscriptions.length}
                </div>
                <div className="stats-subtitle">
                  {subscriptions.length === 0 ? 'No active services' : 'Services running'}
                </div>
              </Card.Body>
            </Card>
          </Col>

          {/* Account Status */}
          <Col md={6} lg={4}>
            <Card className="status-card">
              <Card.Body>
                <div className="status-header">
                  <FaUser className="status-icon" />
                  <span className="status-label">Account Status</span>
                </div>
                <div className="status-value">
                  <Badge bg="success">Active</Badge>
                </div>
                <div className="status-subtitle">
                  Member since Jan 2024
                </div>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        {/* Subscriptions Section */}
        <Row className="mb-4">
          <Col>
            <Card className="subscriptions-card">
              <Card.Header>
                <div className="d-flex justify-content-between align-items-center">
                  <h5 className="mb-0">
                    <FaCrown className="me-2" />
                    {t('subscriptions')}
                  </h5>
                  <Button variant="outline-primary" size="sm" as={Link} to="/services">
                    View All Services
                  </Button>
                </div>
              </Card.Header>
              <Card.Body>
                {subscriptions.length === 0 ? (
                  <div className="text-center py-5">
                    <FaCrown className="no-subscriptions-icon mb-3" />
                    <h5>{t('noSubscriptions')}</h5>
                    <p className="text-muted">Subscribe to our services to get started</p>
                    <Button variant="primary" as={Link} to="/services">
                      {t('subscribeNow')}
                    </Button>
                  </div>
                ) : (
                  <div className="subscriptions-list">
                    {subscriptions.map((subscription) => (
                      <div key={subscription.id} className="subscription-item">
                        <div className="subscription-info">
                          <h6 className="subscription-name">{subscription.name}</h6>
                          <p className="subscription-details">
                            ${subscription.price}/month • Next billing: {subscription.nextBilling}
                          </p>
                        </div>
                        <div className="subscription-status">
                          <Badge bg="success">Active</Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </Card.Body>
            </Card>
          </Col>
        </Row>

        {/* Quick Actions */}
        <Row>
          <Col md={6} lg={3}>
            <Card className="action-card">
              <Card.Body className="text-center">
                <FaWallet className="action-icon mb-3" />
                <h6>Wallet</h6>
                <p className="text-muted small">Manage your funds</p>
                <Button variant="outline-primary" size="sm" as={Link} to="/wallet">
                  View Wallet
                </Button>
              </Card.Body>
            </Card>
          </Col>

          <Col md={6} lg={3}>
            <Card className="action-card">
              <Card.Body className="text-center">
                <FaCrown className="action-icon mb-3" />
                <h6>Services</h6>
                <p className="text-muted small">Browse services</p>
                <Button variant="outline-primary" size="sm" as={Link} to="/services">
                  View Services
                </Button>
              </Card.Body>
            </Card>
          </Col>

          <Col md={6} lg={3}>
            <Card className="action-card">
              <Card.Body className="text-center">
                <FaChartLine className="action-icon mb-3" />
                <h6>Analytics</h6>
                <p className="text-muted small">View usage stats</p>
                <Button variant="outline-primary" size="sm">
                  Coming Soon
                </Button>
              </Card.Body>
            </Card>
          </Col>

          <Col md={6} lg={3}>
            <Card className="action-card">
              <Card.Body className="text-center">
                <FaCog className="action-icon mb-3" />
                <h6>Settings</h6>
                <p className="text-muted small">Account settings</p>
                <Button variant="outline-primary" size="sm">
                  Settings
                </Button>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default UserDashboard;